# Synthetic example

This is not provider output.
